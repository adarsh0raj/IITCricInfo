export interface points {
    team_name: string;
    won: number;
    lost: number;
    tied: number;
    nrr: number;
    points: number;
}